
			const app = new SpeRuntime.Application();
			app.start('./scene.json');
        